package SangFood;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class EditProfileServlet
 */

public class EditProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditProfileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		String newlastname = request.getParameter("NewLastname");
		String newAddress = request.getParameter("NewAddress");
		String newemail=request.getParameter("NewEmail");
		String newPhoneNumber=request.getParameter("NewTel");
		String newcity=request.getParameter("NewCity");
		String newplace=request.getParameter("NewPlace");
		
		System.out.println(session.getAttribute("currentSessionUser"));
		String username = (String) session.getAttribute("currentSessionUser");

		UserDAO.EditProfile(newlastname,newemail,newAddress,newPhoneNumber,newcity,newplace,username);
		
		RequestDispatcher rd = request.getRequestDispatcher("EditProfile.jsp");
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
