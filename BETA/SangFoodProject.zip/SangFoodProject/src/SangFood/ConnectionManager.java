package SangFood;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * 
 * @author sej
 *
 */
public class ConnectionManager {
	static Connection con;
	static String url;
	static String dbname;
	static String driver;
	static String username;
	static String password;
	
	/**
	 * 
	 * @return
	 */
	public static Connection getConnection()
	{
		
		String url="jdbc:mysql://localhost/";
		String dbName="sangFood";
		String driver="com.mysql.jdbc.Driver";
		String userName="root";
		String password="1234";
		try {
			Class.forName(driver).newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sangFood",userName,password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}

}
