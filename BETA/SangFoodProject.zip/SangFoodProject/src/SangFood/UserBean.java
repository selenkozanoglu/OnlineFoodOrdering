package SangFood;


public class UserBean {
private  int user_id;
private String firstName;
private String lastName;
private String password;
private String u_email;
private String username;
private String uaddress;
private int user_type;
private String usrtel;
private String user_city;
private String user_place;
public boolean valid;

/**
 * 
 * @return
 */
public int getUserId(){
	return user_id;
}
/**
 * 
 * @param newUserId
 */
public void setUserId(int newUserId){
	user_id=newUserId;
}
/**
 * 
 * @return
 */
public String getFirstName(){
	return firstName;
}
/**
 * 
 * @param newFirstName
 */
public void setFirstName(String newFirstName){
	firstName=newFirstName;
}
/**
 * 
 * @return
 */
public String getLastName(){
	return lastName;
}
/**
 * 
 * @param newLastName
 */
public void setLastName(String newLastName){
	lastName=newLastName;
}
/**
 * 
 * @return
 */
public String getPassword(){
	return password;
}
/**
 * 
 * @param newPassword
 */
public void setPassword(String newPassword){
	password=newPassword;
}
/**
 * 
 * @return
 */
public String getUsername(){
	return username;
}
/**
 * 
 * @param newUsername
 */
public void setUsername(String newUsername){
	username=newUsername;
}
/**
 * 
 * @return
 */
public String getu_email(){
	return u_email;
}
/**
 * 
 * @param newUserEmail
 */
public void setUEmail(String newUserEmail){
	u_email=newUserEmail;
}
/**
 * 
 * @return
 */
public String getUserAddress(){
	return uaddress;
}
/**
 * 
 * @param newUserAddress
 */
public void setUAddress(String newUserAddress){
	uaddress=newUserAddress;
}
/**
 * 
 * @return
 */
public boolean isValid(){
	return valid;
}
/**
 * 
 * @param newValid
 */
public void setValid(boolean newValid){
	valid=newValid;
}
/**
 * 
 * @return
 */
public int getUserType(){
	return user_type;
}
/**
 * 
 * @param newUserType
 */
public void setUserType(int newUserType){
	user_type=newUserType;
}
/**
 * 
 * @return
 */
public String getUsrTel(){
	return usrtel;
}
/**
 * 
 * @param newusrtel
 */
public void setUsrTel(String newusrtel){
	usrtel=newusrtel;
}
/**
 * 
 * @return
 */
public String getUserCity(){
	return user_city;
	
}
/**
 * 
 * @param newUserCity
 */
public void setUserCity(String newUserCity){
	user_city=newUserCity;
	
}
/**
 * 
 * @return
 */
public String getUserPlace(){
	return user_place;
}
/**
 * 
 * @param newUserPlace
 */
public void setUserPlace(String newUserPlace){
	user_place=newUserPlace;
}
}
