package SangFood;

public class RestaurantBean {
	private String rid;
	private String rest_address;
	private String rest_name;
	private String owner_id;
	private String rest_info;
	private int status;
	
	/**
	 * 
	 * @return
	 */
	public String getRid(){
		return rid;
	}
	/**
	 * 
	 * @param newRid
	 */
	public void setRid(String newRid){
		rid=newRid;
	}
	/**
	 * 
	 * @return
	 */
	public String getRestAddress(){
		return rest_address;
	}
	/**
	 * 
	 * @param newRestAddress
	 */
	public void setRestAddress(String newRestAddress){
		rest_address=newRestAddress;
	
	}
	/**
	 * 
	 * @return
	 */
	public String getRestName(){
		return rest_name;
	}
	/**
	 * 
	 * @param newRestName
	 */
	public void setRestName(String newRestName){
		rest_name=newRestName;
	
	}
	/**
	 * 
	 * @return
	 */
	public String getOwnerId(){
		return owner_id;
	}
	/**
	 * 
	 * @param newOwnerId
	 */
	public void setOwnerId(String newOwnerId){
		owner_id=newOwnerId;
	
	}
	/**
	 * 
	 * @return
	 */
	public String getRestInfo(){
		return rest_info;
	}
	/**
	 * 
	 * @param newRestInfo
	 */
	public void setRestInfo(String newRestInfo){
		rest_info=newRestInfo;
	
	}
	/**
	 * 
	 * @return
	 */
	public int getStatus(){
		return status;
	}
	/**
	 * 
	 * @param newStatus
	 */
	public void setStatus(int newStatus){
		status=newStatus;
	
	}
	
	
}
