package SangFood;

/**
 * 
 * @author sej
 *
 */
public class RestMenuBean {
	private int restaurant_id;
	private String food_name;
	private String food_type;
	private String price;
	private int food_id;
	
	/**
	 * 
	 * @return
	 */
	public int getRestaurantId(){
		return restaurant_id;
	}
	/**
	 * 
	 * @param newrestaurant_id
	 */
	public void setRestaurantId(int  newrestaurant_id){
		restaurant_id=newrestaurant_id;
	}
	/**
	 * 
	 * @return
	 */
	public String getFoodName(){
		return food_name;
	}
	/**
	 * 
	 * @param newFoodName
	 */
	public void setFoodName(String  newFoodName){
		food_name=newFoodName;
	}
	/**
	 * 
	 * @return
	 */
	public String getFoodType(){
		return food_type;
	}
	/**
	 * 
	 * @param newFoodType
	 */
	public void setfoodType(String  newFoodType){
		food_type=newFoodType;
	}
	/**
	 * 
	 * @return
	 */
	public String getPrice(){
		return price;
	}
	/**
	 * 
	 * @param newPrice
	 */
	public void setPrice(String  newPrice){
		price=newPrice;
	}
	/**
	 * 
	 * @return
	 */
public int getFoodId(){
	return food_id;
}
/**
 * 
 * @param newFoodId
 */
public void setFoodId(int newFoodId){
	food_id=newFoodId;
}
}
